

/**
 package user_int;
 import java.sql.*;
 * @author user
 *//*
try {
                String Query="SELECT DISTINCT area FROM senior_citizen";
                System.out.println("ausfxv");
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                System.out.println("ausfxv");
               // Connection con;
                Connection conn;
                conn = DriverManager.getConnection("jdbc:mysql://localhost/mp?" +"user=root&password=abc");
                System.out.println("ausfxv");
                Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(Query);
        while (rs.next()) {
                    String sname=rs.getString("area");
                    System.out.println(sname);
                }
        conn.close();
            } 
            catch (Exception e)
            {   
                String S;
                System.out.println("ausfxv1234");
            }*/